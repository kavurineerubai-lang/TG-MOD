package com.akanksha.chat

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recycler = findViewById<RecyclerView>(R.id.chatList)
        recycler.layoutManager = LinearLayoutManager(this)

        val chats = listOf(
            ChatPreview("Akanksha", "Tap to start chatting", "Now")
        )

        recycler.adapter = ChatListAdapter(chats) {
            startActivity(Intent(this, ChatActivity::class.java))
        }
    }
}
