package com.akanksha.chat

data class ChatMessage(
    val text: String,
    val sentByMe: Boolean,
    val time: String
)
