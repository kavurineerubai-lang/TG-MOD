package com.akanksha.chat

data class ChatPreview(
    val name: String,
    val lastMessage: String,
    val time: String
)
